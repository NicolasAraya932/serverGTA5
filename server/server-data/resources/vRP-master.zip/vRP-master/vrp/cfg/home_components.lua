
local cfg = {}

-- map_entity: {ent,cfg} will fill cfg.pos
cfg.chest = {
  map_entity = {"PoI", {marker_id = 1}}
}

cfg.wardrobe = {
  map_entity = {"PoI", {marker_id = 1}}
}

cfg.gametable = {
  map_entity = {"PoI", {marker_id = 1}}
}

cfg.radio = {
  map_entity = {"PoI", {marker_id = 1}}
}

return cfg
