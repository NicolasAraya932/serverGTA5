local cfg = {}

cfg.whitelist = false -- enable/disable whitelist

return cfg
