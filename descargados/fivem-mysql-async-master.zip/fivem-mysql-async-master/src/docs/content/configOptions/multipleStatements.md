---
id: 18
name: 'multipleStatements'
---
Allow multiple mysql statements per query. Be careful with this, it could increase the scope of SQL injection attacks. (Default: `false`)