---
activeStep: 1
---
###  Install the Resource

After you have installed a database, you will have to add the resource to the server. To do this, first
[download](https://github.com/brouznouf/fivem-mysql-async/releases) the `Source code (zip)`
then extract the contents to the `/resources/` folder of your server configuration and rename the folder to `mysql-async`.

You are done with adding the resource to your server, click on *Next* to proceed with configuring the
resource and the FXServer for the connection.